# Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LinearRegression
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix, mean_squared_error, r2_score

# Load the dataset
file_path = "../GoldPricePrediction/FINAL_USO.csv"  # Update this path
data = pd.read_csv(file_path)

# Preprocess the data by dropping the 'Date' column and setting features and target
data = data.drop('Date', axis=1)
features = ['Open', 'High', 'Low', 'SP_open', 'SP_high', 'SP_low', 'SP_close', 'DJ_open', 'DJ_high', 'DJ_low', 'DJ_close',
            'USO_Open', 'USO_High', 'USO_Low', 'USO_Close']
target = 'Close'
X = data[features]
y = data[target]

# Convert the target into binary for classification tasks (median split for binary classification)
y_binary = np.where(y > y.median(), 1, 0)

# Split data for regression (original target) and classification (binary target)
X_train, X_test, y_train_reg, y_test_reg = train_test_split(X, y, test_size=0.2, random_state=42)
X_train_cls, X_test_cls, y_train_cls, y_test_cls = train_test_split(X, y_binary, test_size=0.2, random_state=42)

# 1. Linear Regression
lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train_reg)
y_pred_reg = lin_reg.predict(X_test)

# 2. Random Forest Classifier
rf_clf = RandomForestClassifier(n_estimators=100, random_state=42)
rf_clf.fit(X_train_cls, y_train_cls)
y_pred_rf = rf_clf.predict(X_test_cls)

# 3. Decision Tree Classifier
dt_clf = DecisionTreeClassifier(random_state=42)
dt_clf.fit(X_train_cls, y_train_cls)
y_pred_dt = dt_clf.predict(X_test_cls)

# 4. SVM Classifier
svm_clf = SVC(kernel='linear', random_state=42)
svm_clf.fit(X_train_cls, y_train_cls)
y_pred_svm = svm_clf.predict(X_test_cls)

# 5. PCA for dimensionality reduction
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)

# Evaluate Linear Regression (MSE and R²)
mse_lin = mean_squared_error(y_test_reg, y_pred_reg)
r2_lin = r2_score(y_test_reg, y_pred_reg)

# Evaluate Classifiers (Accuracy scores)
acc_rf = accuracy_score(y_test_cls, y_pred_rf)
acc_dt = accuracy_score(y_test_cls, y_pred_dt)
acc_svm = accuracy_score(y_test_cls, y_pred_svm)



# Plot the regression results for Linear Regression (Actual vs Predicted)
plt.figure(figsize=(10, 5))
plt.plot(y_test_reg.values, label="Actual Values", color="blue")
plt.plot(y_pred_reg, label="Predicted Values", color="red")
plt.title("Linear Regression: Actual vs Predicted GLD Prices")
plt.xlabel("Actual Gold Price (Close) ")
plt.ylabel("Predicted Gold Price (Close)")
plt.legend()
plt.show()



# Print evaluation metrics
print("Linear Regression - Mean Squared Error:", mse_lin)
print("Linear Regression - R² Score:", r2_lin)


print("Random Forest Classifier - Accuracy:", acc_rf)
print("Decision Tree Classifier - Accuracy:", acc_dt)
print("SVM Classifier - Accuracy:", acc_svm)
