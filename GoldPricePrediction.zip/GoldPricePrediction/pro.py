import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn import metrics
gold_data = pd.read_csv("../GoldPricePrediction/FINAL_USO.csv")
print(gold_data.head())
gold_data.isnull().sum()
features = ['Open', 'High', 'Low', 'SP_open', 'SP_high', 'SP_low', 'SP_close', 'DJ_open', 'DJ_high', 'DJ_low', 'DJ_close',
            'USO_Open', 'USO_High', 'USO_Low', 'USO_Close']
target = 'Close'
X = gold_data[features]
Y = gold_data[target]

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.2)
regressor = RandomForestRegressor(n_estimators=100)
regressor.fit(X_train,Y_train)
test_data_prediction = regressor.predict(X_test)
test_data_prediction = regressor.predict(X_test)
Y_test = list(Y_test)
plt.plot(Y_test, color='blue', label = 'Actual Value')
plt.plot(test_data_prediction, color='green', label='Predicted Value')
plt.title('Actual Price vs Predicted Price')
plt.xlabel('Number of values')
plt.ylabel('GLD Price')
plt.legend()
plt.show()


from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report

# Convert y to categorical classes (e.g., bins for GLD price ranges)
# Example: classify prices into Low, Medium, High based on quantiles
y_classes = pd.qcut(y, q=3, labels=['Low', 'Medium', 'High'])

# Split into training and test sets for classification
X_train, X_test, y_train, y_test = train_test_split(X, y_classes, test_size=0.2, random_state=42)

# Initialize and train Decision Tree Classifier
tree_classifier = DecisionTreeClassifier(random_state=42)
tree_classifier.fit(X_train, y_train)

# Predict with the Decision Tree Classifier
y_pred_tree_class = tree_classifier.predict(X_test)

# Print classification accuracy and classification report
print("Decision Tree Classification Accuracy:", accuracy_score(y_test, y_pred_tree_class))
print("Classification Report:\n", classification_report(y_test, y_pred_tree_class))

# Plot actual vs predicted for classification
# Note: For classification, you may want to use a confusion matrix instead of scatter plot
import seaborn as sns
from sklearn.metrics import confusion_matrix

# Plot confusion matrix for classifier
conf_matrix = confusion_matrix(y_test, y_pred_tree_class)
sns.heatmap(conf_matrix, annot=True, fmt="d", cmap="Blues", xticklabels=['Low', 'Medium', 'High'], yticklabels=['Low', 'Medium', 'High'])
plt.xlabel("Predicted Class")
plt.ylabel("Actual Class")
plt.title("Decision Tree Classifier - Confusion Matrix")
plt.show()


from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# Convert y to categorical classes for classification (e.g., Low, Medium, High)
y_classes = pd.qcut(y, q=3, labels=['Low', 'Medium', 'High'])

# Split into training and test sets for classification
X_train_class, X_test_class, y_train_class, y_test_class = train_test_split(X, y_classes, test_size=0.2, random_state=42)

# Initialize and train Random Forest Classifier
rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
rf_classifier.fit(X_train_class, y_train_class)

# Predict with the Random Forest Classifier
y_pred_rf_class = rf_classifier.predict(X_test_class)

# Print classification accuracy and classification report
print("Random Forest Classifier Accuracy:", accuracy_score(y_test_class, y_pred_rf_class))
print("Classification Report:\n", classification_report(y_test_class, y_pred_rf_class))

# Plot confusion matrix for classifier
conf_matrix = confusion_matrix(y_test_class, y_pred_rf_class)
sns.heatmap(conf_matrix, annot=True, fmt="d", cmap="Blues", xticklabels=['Low', 'Medium', 'High'], yticklabels=['Low', 'Medium', 'High'])
plt.xlabel("Predicted Class")
plt.ylabel("Actual Class")
plt.title("Random Forest Classifier - Confusion Matrix")
plt.show()
