import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

data = pd.read_csv("../GoldPricePrediction/FINAL_USO.csv")


print(data.head())
data.info()

# Feature select
features = ['Open', 'High', 'Low', 'SP_open', 'SP_high', 'SP_low', 'SP_close', 'DJ_open', 'DJ_high', 'DJ_low', 'DJ_close',
            'USO_Open', 'USO_High', 'USO_Low', 'USO_Close']
target = 'Close'

# Drop rows with missing values
data_cleaned = data.dropna()
#cat to numer
categorical_columns = ['Open', 'High', 'Low', 'SP_open', 'SP_high', 'SP_low', 'SP_close',
                       'DJ_open', 'DJ_high', 'DJ_low', 'DJ_close', 'USO_Open', 'USO_High',
                       'USO_Low', 'USO_Close']

label_encoders = {}
for col in categorical_columns:
        le = LabelEncoder()
        data_cleaned[col] = le.fit_transform(data_cleaned[col])

#Feature and Target Selection
X = data_cleaned[features]
y = data_cleaned[target]

#spliting data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)


# Feature Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)


# Train a Linear Regression model
from sklearn.linear_model import LinearRegression
model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

# Evaluate the model
from sklearn.metrics import mean_squared_error, r2_score
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

# Plot actual vs predicted gold prices
plt.figure(figsize=(8,6))
plt.scatter(y_test, y_pred, color='blue')
plt.plot(y_test, y_test, color='red', label="Perfect Prediction Line")
plt.xlabel('Actual Gold Price (Close)')
plt.ylabel('Predicted Gold Price (Close)')
plt.title('Actual vs Predicted Gold Price')
plt.legend()
plt.show()

print('Mean Squared Error:', mse)
print('R^2 Score:', r2)
